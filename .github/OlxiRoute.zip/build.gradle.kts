plugins {
    id("com.android.application") version "8.9.1" apply false
    kotlin("android") version "2.2.21" apply false
}
