package com.olxi.route

import android.content.Context
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView

fun Context.button(label: String, onClick: () -> Unit): Button =
    Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

fun Context.heading(label: String): TextView =
    TextView(this).apply {
        text = label
        textSize = 14f
        setPadding(0, 32, 0, 8)
    }

fun Context.hint(label: String): TextView =
    TextView(this).apply {
        text = label
        setPadding(0, 8, 0, 4)
    }

fun Context.switchRow(label: String, checked: Boolean): Switch =
    Switch(this).apply {
        text = label
        isChecked = checked
    }

fun Context.numberField(value: Int): EditText =
    EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(value.toString())
    }
