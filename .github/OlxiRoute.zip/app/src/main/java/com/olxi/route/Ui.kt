package com.olxi.route

import android.content.Context
import android.graphics.Typeface
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.sectionTitle(t: String): TextView = TextView(this).apply {
    text = t
    textSize = 13f
    setTypeface(null, Typeface.BOLD)
    setPadding(0, 0, 0, dp(8))
}

/** Карточка Material с заголовком и содержимым, которое задаётся в блоке build. */
fun Context.card(title: String?, build: LinearLayout.() -> Unit): MaterialCardView {
    val inner = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        if (title != null) addView(sectionTitle(title))
        build()
    }
    return MaterialCardView(this).apply {
        radius = dp(16).toFloat()
        cardElevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
        addView(inner)
    }
}

fun Context.button(label: String, onClick: () -> Unit): MaterialButton =
    MaterialButton(this).apply {
        text = label
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

fun Context.switchRow(label: String, checked: Boolean): SwitchCompat =
    SwitchCompat(this).apply {
        text = label
        isChecked = checked
        setPadding(0, dp(8), 0, dp(8))
    }

fun Context.numberField(value: Int): EditText =
    EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(value.toString())
    }

fun Context.hint(label: String): TextView = TextView(this).apply {
    text = label
    textSize = 12f
    alpha = 0.7f
    setPadding(0, dp(8), 0, dp(4))
}
