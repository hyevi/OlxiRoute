package com.olxi.route

interface TunnelBackend {
    /** null — туннель поднят; иначе текст ошибки для журнала. */
    fun start(config: WgConfig): String?

    fun stop()

    /** true — если туннель сейчас поднят. */
    fun isUp(): Boolean
}
