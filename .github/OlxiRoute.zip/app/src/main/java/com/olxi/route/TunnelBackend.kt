package com.olxi.route

interface TunnelBackend {
    /** Поднимает туннель. true — если туннель перешёл в состояние UP. */
    fun start(config: WgConfig): Boolean

    fun stop()

    /** true — если туннель сейчас поднят. */
    fun isUp(): Boolean
}
