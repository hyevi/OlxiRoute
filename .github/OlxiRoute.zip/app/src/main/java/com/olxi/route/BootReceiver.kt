package com.olxi.route

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = Prefs(context)
        // Если VPN-разрешение ещё не выдано, prepare вернёт Intent, и автозапуск пропускаем.
        if (prefs.connectOnBoot && VpnService.prepare(context) == null) {
            VpnTunnelService.start(context)
        }
    }
}
