package com.olxi.route

import android.content.Context
import java.io.File

object ConfigStore {
    private fun dir(ctx: Context) = File(ctx.filesDir, "configs").apply { mkdirs() }

    fun names(ctx: Context): List<String> =
        dir(ctx).listFiles { f -> f.extension == "conf" }
            ?.map { it.nameWithoutExtension }?.sorted() ?: emptyList()

    fun importText(ctx: Context, rawName: String, text: String): WgConfig {
        val name = rawName.removeSuffix(".conf").replace(Regex("[^A-Za-z0-9_-]"), "_")
        val cfg = ConfigParser.parse(name, text)
        File(dir(ctx), "$name.conf").writeText(text)
        return cfg
    }

    fun loadAll(ctx: Context): List<WgConfig> =
        dir(ctx).listFiles { f -> f.extension == "conf" }?.mapNotNull {
            runCatching { ConfigParser.parse(it.nameWithoutExtension, it.readText()) }.getOrNull()
        } ?: emptyList()

    fun delete(ctx: Context, name: String) {
        File(dir(ctx), "$name.conf").delete()
    }

    fun deleteAll(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }
}
