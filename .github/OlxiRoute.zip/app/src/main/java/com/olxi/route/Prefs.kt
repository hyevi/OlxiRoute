package com.olxi.route

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("olxi", Context.MODE_PRIVATE)

    /** 0 — системная, 1 — светлая, 2 — тёмная */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var autoPick: Boolean
        get() = sp.getBoolean("auto_pick", true)
        set(v) { sp.edit().putBoolean("auto_pick", v).apply() }

    var autoReconnect: Boolean
        get() = sp.getBoolean("auto_reconnect", true)
        set(v) { sp.edit().putBoolean("auto_reconnect", v).apply() }

    var connectOnBoot: Boolean
        get() = sp.getBoolean("connect_on_boot", false)
        set(v) { sp.edit().putBoolean("connect_on_boot", v).apply() }

    var showNotification: Boolean
        get() = sp.getBoolean("show_notification", true)
        set(v) { sp.edit().putBoolean("show_notification", v).apply() }

    var reconnectDelaySec: Int
        get() = sp.getInt("reconnect_delay", 10)
        set(v) { sp.edit().putInt("reconnect_delay", v).apply() }

    var checkIntervalSec: Int
        get() = sp.getInt("check_interval", 30)
        set(v) { sp.edit().putInt("check_interval", v).apply() }

    var preferredConfig: String?
        get() = sp.getString("preferred", null)
        set(v) { sp.edit().putString("preferred", v).apply() }
}

fun applyTheme(ctx: Context) {
    AppCompatDelegate.setDefaultNightMode(
        when (Prefs(ctx).theme) {
            1 -> AppCompatDelegate.MODE_NIGHT_NO
            2 -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
    )
}
