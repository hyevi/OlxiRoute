package com.olxi.route

import android.content.Context
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.backend.Tunnel
import org.amnezia.awg.backend.TunnelActionHandler
import org.amnezia.awg.config.Config
import java.io.ByteArrayInputStream

/** Бэкенд на библиотеке amneziawg-android. Туннель и VpnService ведёт библиотека. */
class AwgBackend(context: Context) : TunnelBackend {
    private val backend = GoBackend(context, object : TunnelActionHandler {
        override fun runPreUp(cmds: Collection<String>) {}
        override fun runPostUp(cmds: Collection<String>) {}
        override fun runPreDown(cmds: Collection<String>) {}
        override fun runPostDown(cmds: Collection<String>) {}
    })

    private val tunnel = object : Tunnel {
        override fun getName() = "olxi"
        override fun onStateChange(state: Tunnel.State) {}
        override fun isIpv4ResolutionPreferred(): Boolean? = null
        override fun isMetered(): Boolean? = null
    }

    override fun start(config: WgConfig): Boolean = try {
        val cfg = Config.parse(ByteArrayInputStream(config.raw.toByteArray()))
        backend.setState(tunnel, Tunnel.State.UP, cfg) == Tunnel.State.UP
    } catch (e: Exception) {
        false
    }

    override fun stop() {
        try {
            backend.setState(tunnel, Tunnel.State.DOWN, null)
        } catch (_: Exception) {
        }
    }

    override fun isUp(): Boolean = try {
        backend.getState(tunnel) == Tunnel.State.UP
    } catch (_: Exception) {
        false
    }
}
