package com.olxi.route

import android.content.Context
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.backend.Tunnel
import org.amnezia.awg.backend.TunnelActionHandler
import org.amnezia.awg.config.Config
import java.io.ByteArrayInputStream

/** Бэкенд на библиотеке amneziawg-android. Туннель и VpnService ведёт библиотека. */
class AwgBackend(context: Context) : TunnelBackend {
    private val backend = GoBackend(context, object : TunnelActionHandler {
        override fun runPreUp(cmds: Collection<String>) {}
        override fun runPostUp(cmds: Collection<String>) {}
        override fun runPreDown(cmds: Collection<String>) {}
        override fun runPostDown(cmds: Collection<String>) {}
    })

    private val tunnel = object : Tunnel {
        override fun getName() = "olxi"
        override fun onStateChange(state: Tunnel.State) {}
        override fun isIpv4ResolutionPreferred(): Boolean = false
        override fun isMetered(): Boolean = false
    }

    private var lastConfig: Config? = null

    override fun start(config: WgConfig): String? {
        val cfg = try {
            Config.parse(ByteArrayInputStream(config.raw.toByteArray()))
        } catch (e: Throwable) {
            return explain("разбор конфига", e)
        }
        lastConfig = cfg
        return try {
            val state = backend.setState(tunnel, Tunnel.State.UP, cfg)
            if (state == Tunnel.State.UP) {
                null
            } else {
                val msg = "туннель не поднялся, состояние: $state"
                AppLog.add(msg)
                msg
            }
        } catch (e: Throwable) {
            explain("запуск туннеля", e)
        }
    }

    override fun stop() {
        try {
            lastConfig?.let { backend.setState(tunnel, Tunnel.State.DOWN, it) }
        } catch (_: Throwable) {
        }
    }

    override fun isUp(): Boolean = try {
        backend.getState(tunnel) == Tunnel.State.UP
    } catch (_: Throwable) {
        false
    }

    /** Пишет в журнал подробности ошибки: этап, класс, текст, причину и первые строки стека. */
    private fun explain(stage: String, e: Throwable): String {
        val cause = e.cause?.let { " / причина: ${it.javaClass.name}: ${it.message ?: "без текста"}" } ?: ""
        val msg = "${e.javaClass.name}: ${e.message ?: "без текста"}$cause"
        AppLog.add("Ошибка: $stage")
        AppLog.add("причина: $msg")
        e.stackTrace.take(5).forEach { AppLog.add("  at $it") }
        return "$stage: $msg"
    }
}
