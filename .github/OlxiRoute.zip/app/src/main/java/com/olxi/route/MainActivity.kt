package com.olxi.route

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var modeView: TextView
    private lateinit var toggleBtn: MaterialButton
    private lateinit var spinner: Spinner
    private lateinit var prefInfo: TextView
    private lateinit var logView: TextView

    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { importUri(it) }
        refreshConfigs()
    }

    private val vpnConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) VpnTunnelService.start(this) else toast("Нужно разрешение VPN")
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyTheme(this)
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        buildUi()
    }

    private fun buildUi() {
        statusView = TextView(this).apply {
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        }
        modeView = TextView(this).apply { textSize = 13f }
        toggleBtn = button("Подключить") { toggle() }
        spinner = Spinner(this)
        prefInfo = TextView(this).apply { textSize = 13f }
        logView = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
        }

        val statusCard = card("Статус") {
            addView(statusView)
            addView(modeView)
            addView(toggleBtn)
        }
        val configsCard = card("Конфиги") {
            addView(spinner)
            addView(prefInfo)
            addView(button("Добавить .conf") { pickFiles.launch(arrayOf("*/*")) })
            addView(button("Сделать предпочтительным") { setPreferred() })
            addView(button("Удалить выбранный") { deleteSelected() })
        }
        val logCard = card("Журнал") {
            addView(logView)
            addView(button("Копировать журнал") { copyLog() })
            addView(button("Очистить журнал") {
                AppLog.clear()
                refreshLog()
            })
        }
        val settingsBtn = button("Настройки") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(statusCard)
            addView(configsCard)
            addView(logCard)
            addView(settingsBtn)
        }
        setContentView(ScrollView(this).apply { addView(column) })
    }

    override fun onStart() {
        super.onStart()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { VpnStatus.text.collect { statusView.text = it } }
                launch {
                    combine(VpnStatus.running, VpnStatus.connected) { r, c -> r to c }
                        .collect { (running, connected) -> applyColors(running, connected) }
                }
            }
        }
    }

    private fun applyColors(running: Boolean, connected: Boolean) {
        val color = when {
            connected -> 0xFF2E7D32.toInt()
            running -> 0xFFEF6C00.toInt()
            else -> 0xFF757575.toInt()
        }
        statusView.setTextColor(color)
        toggleBtn.text = if (running) "Отключить" else "Подключить"
    }

    override fun onResume() {
        super.onResume()
        refreshConfigs()
        refreshLog()
    }

    private fun toggle() {
        if (VpnStatus.running.value) {
            VpnTunnelService.stop(this)
            return
        }
        if (ConfigStore.names(this).isEmpty()) {
            toast("Сначала добавь .conf")
            return
        }
        val consent = VpnService.prepare(this)
        if (consent != null) vpnConsent.launch(consent) else VpnTunnelService.start(this)
    }

    private fun refreshConfigs() {
        val names = ConfigStore.names(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val pref = prefs.preferredConfig
        if (pref != null) {
            val idx = names.indexOf(pref)
            if (idx >= 0) spinner.setSelection(idx)
        }
        modeView.text = if (prefs.autoPick) "Режим: авто-выбор по пингу" else "Режим: один конфиг"
        prefInfo.text = if (pref != null) "Предпочтительный: $pref" else "Предпочтительный не выбран"
    }

    private fun refreshLog() {
        logView.text = AppLog.text().ifEmpty { "Пусто" }
    }

    private fun copyLog() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("OlxiRoute log", AppLog.text()))
        toast("Журнал скопирован")
    }

    private fun setPreferred() {
        val name = spinner.selectedItem as? String ?: return
        prefs.preferredConfig = name
        toast("Предпочтительный: $name")
        refreshConfigs()
    }

    private fun deleteSelected() {
        val name = spinner.selectedItem as? String ?: return
        ConfigStore.delete(this, name)
        if (prefs.preferredConfig == name) prefs.preferredConfig = null
        refreshConfigs()
    }

    private fun importUri(uri: Uri) {
        val displayName = contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: "config_${System.currentTimeMillis()}"
        try {
            val text = contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() }
                ?: error("не удалось открыть файл")
            ConfigStore.importText(this, displayName, text)
            toast("Добавлен: $displayName")
        } catch (e: Exception) {
            toast("$displayName: ${e.message}")
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
