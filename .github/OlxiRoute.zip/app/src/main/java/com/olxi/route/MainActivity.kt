package com.olxi.route

import android.Manifest
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var statusView: TextView
    private lateinit var toggleBtn: Button
    private lateinit var spinner: Spinner
    private lateinit var modeInfo: TextView
    private lateinit var logView: TextView

    private val pickFiles = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { importUri(it) }
        refreshConfigs()
    }

    private val vpnConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == RESULT_OK) VpnTunnelService.start(this) else toast("Нужно разрешение VPN")
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        applyTheme(this)
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        buildUi()
    }

    private fun buildUi() {
        statusView = TextView(this).apply { textSize = 18f; setPadding(0, 0, 0, 24) }
        toggleBtn = Button(this).apply {
            text = "Старт"
            setOnClickListener { toggle() }
        }
        spinner = Spinner(this)
        modeInfo = TextView(this)
        logView = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
        }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(40, 40, 40, 40)
        col.addView(statusView)
        col.addView(toggleBtn)
        col.addView(heading("Конфиги"))
        col.addView(spinner)
        col.addView(modeInfo)
        col.addView(button("Добавить .conf") { pickFiles.launch(arrayOf("*/*")) })
        col.addView(button("Сделать предпочтительным") { setPreferred() })
        col.addView(button("Удалить выбранный") { deleteSelected() })
        col.addView(button("Настройки") { startActivity(Intent(this, SettingsActivity::class.java)) })
        col.addView(heading("Журнал"))
        col.addView(logView)
        col.addView(button("Очистить журнал") {
            AppLog.clear()
            refreshLog()
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onStart() {
        super.onStart()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { VpnStatus.text.collect { statusView.text = it } }
                launch { VpnStatus.running.collect { toggleBtn.text = if (it) "Стоп" else "Старт" } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshConfigs()
        refreshLog()
    }

    private fun toggle() {
        if (VpnStatus.running.value) {
            VpnTunnelService.stop(this)
            return
        }
        if (ConfigStore.names(this).isEmpty()) {
            toast("Сначала добавь .conf")
            return
        }
        val consent = VpnService.prepare(this)
        if (consent != null) vpnConsent.launch(consent) else VpnTunnelService.start(this)
    }

    private fun refreshConfigs() {
        val names = ConfigStore.names(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val pref = prefs.preferredConfig
        if (pref != null) {
            val idx = names.indexOf(pref)
            if (idx >= 0) spinner.setSelection(idx)
        }
        val mode = if (prefs.autoPick) "авто по пингу" else "один конфиг"
        modeInfo.text = if (pref != null) "Режим: $mode\nПредпочтительный: $pref" else "Режим: $mode"
    }

    private fun refreshLog() {
        logView.text = AppLog.text().ifEmpty { "Пусто" }
    }

    private fun setPreferred() {
        val name = spinner.selectedItem as? String ?: return
        prefs.preferredConfig = name
        toast("Предпочтительный: $name")
        refreshConfigs()
    }

    private fun deleteSelected() {
        val name = spinner.selectedItem as? String ?: return
        ConfigStore.delete(this, name)
        if (prefs.preferredConfig == name) prefs.preferredConfig = null
        refreshConfigs()
    }

    private fun importUri(uri: Uri) {
        val displayName = contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: "config_${System.currentTimeMillis()}"
        try {
            val text = contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() }
                ?: error("не удалось открыть файл")
            ConfigStore.importText(this, displayName, text)
            toast("Добавлен: $displayName")
        } catch (e: Exception) {
            toast("$displayName: ${e.message}")
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
