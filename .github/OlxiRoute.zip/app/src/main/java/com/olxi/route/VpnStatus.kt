package com.olxi.route

import kotlinx.coroutines.flow.MutableStateFlow

object VpnStatus {
    val text = MutableStateFlow("Выключено")
    val connected = MutableStateFlow(false)
    val running = MutableStateFlow(false)
}
