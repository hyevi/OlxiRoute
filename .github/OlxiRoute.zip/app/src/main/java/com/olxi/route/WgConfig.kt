package com.olxi.route

data class WgConfig(
    val name: String,
    val privateKey: String,
    val addresses: List<String>,
    val dns: List<String>,
    val mtu: Int?,
    val i1: String?,
    val peerPublicKey: String,
    val allowedIps: List<String>,
    val endpointHost: String,
    val endpointPort: Int,
    val keepalive: Int?,
    val raw: String
)

object ConfigParser {
    fun parse(name: String, text: String): WgConfig {
        val iface = HashMap<String, String>()
        val peer = HashMap<String, String>()
        var section: MutableMap<String, String>? = null

        text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .forEach { line ->
                when {
                    line.equals("[Interface]", ignoreCase = true) -> section = iface
                    line.equals("[Peer]", ignoreCase = true) -> section = peer
                    else -> {
                        val eq = line.indexOf('=')
                        if (eq > 0) section?.put(line.substring(0, eq).trim(), line.substring(eq + 1).trim())
                    }
                }
            }

        val privateKey = iface["PrivateKey"] ?: error("нет PrivateKey")
        val peerKey = peer["PublicKey"] ?: error("нет PublicKey в [Peer]")
        val endpoint = peer["Endpoint"] ?: error("нет Endpoint")
        val host = endpoint.substringBeforeLast(':').removePrefix("[").removeSuffix("]")
        val port = endpoint.substringAfterLast(':').toIntOrNull() ?: error("неверный порт в Endpoint")

        return WgConfig(
            name = name,
            privateKey = privateKey,
            addresses = list(iface["Address"]),
            dns = list(iface["DNS"]),
            mtu = iface["MTU"]?.toIntOrNull(),
            i1 = iface["I1"],
            peerPublicKey = peerKey,
            allowedIps = list(peer["AllowedIPs"]),
            endpointHost = host,
            endpointPort = port,
            keepalive = peer["PersistentKeepalive"]?.toIntOrNull(),
            raw = text
        )
    }

    private fun list(v: String?): List<String> =
        v?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
}
