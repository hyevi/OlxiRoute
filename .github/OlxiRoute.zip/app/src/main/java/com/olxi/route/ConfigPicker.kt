package com.olxi.route

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

object ConfigPicker {
    /** Возвращает конфиги по возрастанию пинга. Без ответа на ping конфиг остаётся в конце. */
    suspend fun rank(configs: List<WgConfig>): List<Pair<WgConfig, Long?>> = coroutineScope {
        configs
            .map { c -> async { c to pingMs(c.endpointHost) } }
            .awaitAll()
            .sortedWith(compareBy<Pair<WgConfig, Long?>>({ it.second == null }, { it.second ?: 0L }))
    }

    suspend fun pingMs(host: String): Long? = withContext(Dispatchers.IO) {
        try {
            val p = ProcessBuilder("ping", "-c", "3", host).redirectErrorStream(true).start()
            if (!p.waitFor(15, TimeUnit.SECONDS)) {
                p.destroy()
                return@withContext null
            }
            val out = p.inputStream.bufferedReader().readText()
            Regex("""=\s*[\d.]+/([\d.]+)/""").find(out)?.groupValues?.get(1)?.toDouble()?.toLong()
        } catch (e: Exception) {
            null
        }
    }
}
