package com.olxi.route

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class VpnTunnelService : Service() {

    companion object {
        const val ACTION_STOP = "com.olxi.route.STOP"
        private const val CHANNEL = "olxi_tunnel"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, VpnTunnelService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, VpnTunnelService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var backend: TunnelBackend
    private lateinit var prefs: Prefs
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        backend = AwgBackend(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Туннель", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification("Подключение..."))
        if (job?.isActive != true) job = scope.launch { runLoop() }
        return START_NOT_STICKY
    }

    private suspend fun runLoop() {
        VpnStatus.running.value = true
        AppLog.add("Сервис запущен")
        try {
            while (true) {
                val configs = ConfigStore.loadAll(this)
                if (configs.isEmpty()) {
                    report("Нет конфигов")
                    break
                }

                val order: List<Pair<WgConfig, Long?>> = if (prefs.autoPick) {
                    report("Замер пинга...")
                    ConfigPicker.rank(configs)
                } else {
                    val pref = configs.find { it.name == prefs.preferredConfig } ?: configs.first()
                    listOf(pref to null)
                }

                var active: Pair<WgConfig, Long?>? = null
                for (candidate in order) {
                    val cfg = candidate.first
                    report("Подключение: ${cfg.name}")
                    val err = backend.start(cfg)
                    if (err == null) {
                        active = candidate
                        break
                    }
                    backend.stop()
                    AppLog.add("Не поднялся: ${cfg.name} — $err")
                }

                if (active == null) {
                    report("Не удалось подключиться")
                    if (!prefs.autoReconnect) break
                    delay(prefs.reconnectDelaySec * 1000L)
                    continue
                }

                val (cfg, ping) = active
                val pingText = if (ping != null) " ($ping мс)" else ""
                reportConnected("Подключено: ${cfg.name}$pingText")

                val interval = prefs.checkIntervalSec.coerceAtLeast(5) * 1000L
                while (true) {
                    delay(interval)
                    if (!backend.isUp()) {
                        AppLog.add("Туннель опустился")
                        break
                    }
                }
                backend.stop()

                if (!prefs.autoReconnect) {
                    report("Соединение потеряно")
                    break
                }
                report("Переподключение...")
                delay(prefs.reconnectDelaySec * 1000L)
            }
        } finally {
            backend.stop()
            VpnStatus.connected.value = false
            VpnStatus.running.value = false
            AppLog.add("Сервис остановлен")
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun shutdown() {
        job?.cancel()
        backend.stop()
        VpnStatus.connected.value = false
        VpnStatus.running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun report(text: String) {
        VpnStatus.text.value = text
        VpnStatus.connected.value = false
        AppLog.add(text)
        updateNotification(text)
    }

    private fun reportConnected(text: String) {
        VpnStatus.text.value = text
        VpnStatus.connected.value = true
        AppLog.add(text)
        updateNotification(text)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, VpnTunnelService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val detailed = prefs.showNotification
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("OlxiRoute")
            .setContentText(if (detailed) text else "Работает")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .setPriority(if (detailed) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_MIN)
            .addAction(android.R.drawable.ic_media_pause, "Стоп", stopIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        scope.cancel()
        if (::backend.isInitialized) backend.stop()
        VpnStatus.connected.value = false
        VpnStatus.running.value = false
        super.onDestroy()
    }
}
