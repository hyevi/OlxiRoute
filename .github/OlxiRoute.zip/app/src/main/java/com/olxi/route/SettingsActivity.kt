package com.olxi.route

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        applyTheme(this)
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val themeSpinner = Spinner(this)
        themeSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Системная", "Светлая", "Тёмная")
        )
        themeSpinner.setSelection(prefs.theme)

        val autoPick = switchRow("Авто-выбор по пингу", prefs.autoPick)
        val autoReconnect = switchRow("Переподключаться при обрыве", prefs.autoReconnect)
        val connectOnBoot = switchRow("Включать при загрузке телефона", prefs.connectOnBoot)
        val showNotif = switchRow("Подробности в уведомлении", prefs.showNotification)
        val delayField = numberField(prefs.reconnectDelaySec)
        val checkField = numberField(prefs.checkIntervalSec)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(40, 40, 40, 40)
        col.addView(heading("Тема"))
        col.addView(themeSpinner)
        col.addView(heading("Поведение"))
        col.addView(autoPick)
        col.addView(autoReconnect)
        col.addView(connectOnBoot)
        col.addView(showNotif)
        col.addView(heading("Тайминги"))
        col.addView(hint("Пауза перед переподключением, сек (3–600)"))
        col.addView(delayField)
        col.addView(hint("Проверка туннеля, сек (5–600)"))
        col.addView(checkField)
        col.addView(heading("Действия"))
        col.addView(button("Сохранить") {
            prefs.theme = themeSpinner.selectedItemPosition
            prefs.autoPick = autoPick.isChecked
            prefs.autoReconnect = autoReconnect.isChecked
            prefs.connectOnBoot = connectOnBoot.isChecked
            prefs.showNotification = showNotif.isChecked
            prefs.reconnectDelaySec = delayField.text.toString().toIntOrNull()?.coerceIn(3, 600) ?: 10
            prefs.checkIntervalSec = checkField.text.toString().toIntOrNull()?.coerceIn(5, 600) ?: 30
            applyTheme(this)
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
            finish()
        })
        col.addView(button("Очистить журнал") {
            AppLog.clear()
            Toast.makeText(this, "Журнал очищен", Toast.LENGTH_SHORT).show()
        })
        col.addView(button("Удалить все конфиги") {
            AlertDialog.Builder(this)
                .setTitle("Удалить все конфиги?")
                .setPositiveButton("Удалить") { _, _ ->
                    ConfigStore.deleteAll(this)
                    prefs.preferredConfig = null
                    Toast.makeText(this, "Конфиги удалены", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Отмена", null)
                .show()
        })
        col.addView(heading("О приложении"))
        col.addView(hint("OlxiRoute 0.3\nТуннель: amneziawg-android 2.3.7\nОбнаружение торрентов не реализовано."))

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
