package com.olxi.route

import android.app.AlertDialog
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs

    override fun onCreate(savedInstanceState: Bundle?) {
        applyTheme(this)
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        val ctx = this

        val themeSpinner = Spinner(ctx)
        themeSpinner.adapter = ArrayAdapter(
            ctx, android.R.layout.simple_spinner_dropdown_item,
            listOf("Системная", "Светлая", "Тёмная")
        )
        themeSpinner.setSelection(prefs.theme)

        val autoPick = ctx.switchRow("Авто-выбор по пингу", prefs.autoPick)
        val autoReconnect = ctx.switchRow("Переподключаться при обрыве", prefs.autoReconnect)
        val connectOnBoot = ctx.switchRow("Включать при загрузке телефона", prefs.connectOnBoot)
        val showNotif = ctx.switchRow("Подробности в уведомлении", prefs.showNotification)
        val delayField = ctx.numberField(prefs.reconnectDelaySec)
        val checkField = ctx.numberField(prefs.checkIntervalSec)

        val themeCard = ctx.card("Тема") { addView(themeSpinner) }
        val behaviorCard = ctx.card("Поведение") {
            addView(autoPick)
            addView(autoReconnect)
            addView(connectOnBoot)
            addView(showNotif)
        }
        val timingCard = ctx.card("Тайминги") {
            addView(ctx.hint("Пауза перед переподключением, сек (3–600)"))
            addView(delayField)
            addView(ctx.hint("Проверка туннеля, сек (5–600)"))
            addView(checkField)
        }
        val actionsCard = ctx.card("Действия") {
            addView(ctx.button("Сохранить") {
                prefs.theme = themeSpinner.selectedItemPosition
                prefs.autoPick = autoPick.isChecked
                prefs.autoReconnect = autoReconnect.isChecked
                prefs.connectOnBoot = connectOnBoot.isChecked
                prefs.showNotification = showNotif.isChecked
                prefs.reconnectDelaySec = delayField.text.toString().toIntOrNull()?.coerceIn(3, 600) ?: 10
                prefs.checkIntervalSec = checkField.text.toString().toIntOrNull()?.coerceIn(5, 600) ?: 30
                applyTheme(ctx)
                Toast.makeText(ctx, "Сохранено", Toast.LENGTH_SHORT).show()
                ctx.finish()
            })
            addView(ctx.button("Очистить журнал") {
                AppLog.clear()
                Toast.makeText(ctx, "Журнал очищен", Toast.LENGTH_SHORT).show()
            })
            addView(ctx.button("Удалить все конфиги") {
                AlertDialog.Builder(ctx)
                    .setTitle("Удалить все конфиги?")
                    .setPositiveButton("Удалить") { _, _ ->
                        ConfigStore.deleteAll(ctx)
                        prefs.preferredConfig = null
                        Toast.makeText(ctx, "Конфиги удалены", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            })
        }
        val aboutCard = ctx.card("О приложении") {
            addView(ctx.hint("OlxiRoute 0.4\nТуннель: amneziawg-android 2.3.7\nОбнаружение торрентов не реализовано."))
        }

        val column = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(themeCard)
            addView(behaviorCard)
            addView(timingCard)
            addView(actionsCard)
            addView(aboutCard)
        }
        setContentView(ScrollView(ctx).apply { addView(column) })
    }
}
